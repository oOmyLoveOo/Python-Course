# producto.py
# Definición de la clase Producto para el sistema de gestión de inventario

class Producto:
    """
    Clase que representa un producto electrónico en el inventario.
    
    Atributos a implementar:
    - id: Identificador único del producto (puede ser None para productos nuevos)
    - nombre: Nombre del producto
    - categoria: Categoría a la que pertenece (Smartphone, Laptop, etc.)
    - precio: Precio de venta en euros
    - stock: Cantidad disponible en almacén
    - fabricante: Empresa fabricante del producto
    """
    
    def __init__(self, id=None, nombre="", categoria="", precio=0.0, stock=0, fabricante=""):
        """
        Constructor de la clase Producto.
        Inicializa los atributos con los valores proporcionados.
        
        TODO: Inicializar todos los atributos necesarios
        """
        # Completar la inicialización de atributos aquí
        self.id = id
        self.nombre = nombre
        self.categoria = categoria
        self.precio = precio
        self.stock = stock
        self.fabricante = fabricante
    
    def __str__(self):
        """
        Método que devuelve una representación en texto del producto.
        
        Returns:
            str: Cadena con información formateada del producto
            
        TODO: Crear un formato adecuado que muestre toda la información relevante
        """
        # Implementar la representación en texto del producto
        return f"ID: {self.id or 'N/A'} | {self.nombre} | {self.categoria} | {self.precio} | {self.stock} | {self.fabricante}"
    
    def to_dict(self):
        """
        Convierte el objeto a un diccionario para facilitar su procesamiento.
        
        Returns:
            dict: Diccionario con los atributos del producto
            
        TODO: Convertir todos los atributos a un diccionario
        """
        # Implementar la conversión a diccionario
        return {
            "id":self.id if self.id else "N/A",
            "nombre":self.nombre,
            "categoria": self.categoria,
            "precio": self.precio,
            "stock":self.stock,
            "fabricante":self.fabricante,
        }
    
    @classmethod
    def from_dict(cls, datos):
        """
        Método de clase que crea una instancia a partir de un diccionario.
        
        Args:
            datos (dict): Diccionario con los atributos del producto
            
        Returns:
            Producto: Nueva instancia de la clase Producto
            
        TODO: Crear y devolver una nueva instancia con los datos del diccionario
        """
        # Implementar la creación de instancia desde diccionario
        if not isinstance(datos, dict):
            return None
        return cls(
            id = datos.get('id', "N/A"),
            nombre = datos.get('nombre', ""),
              categoria =datos.get('categoria', ""),
            precio = datos.get('precio', 0.0),
            stock =datos.get('stock', 0),
            fabricante = datos.get('fabricante', ""),
        )
