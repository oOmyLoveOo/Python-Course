# main.py
# Programa principal del sistema de gestión de inventario

from producto import Producto
from database import GestorBD

def obtener_texto(solicitud, campo):
    while True:
        valor = input(solicitud).strip()
        if not valor:
            print(f"Dato no válido para el {campo}. Por favor, inténtelo de nuevo.")
            continue
        return valor

def obtener_numero(solicitud, campo, tipo=float, min_valor=0):
    while True:
        valor = input(solicitud).strip()
        if not valor:
            print(f"Dato no válido para el {campo}. Por favor, inténtelo de nuevo.")
            continue
        
        try:
            numero = tipo(valor)
            if numero < min_valor:
                print(f"El {campo} no puede ser menor que {min_valor}. Por favor, inténtelo de nuevo.")
                continue
            return numero
        except ValueError:
            print(f"Por favor, introduzca un valor numérico válido para el {campo}.")

def solicitar_datos_producto():
    datos_producto = {}
    
    nombre = obtener_texto("Nombre del producto: ", "nombre")
    datos_producto["nombre"] = nombre

    categoria = obtener_texto("Categoría del producto: ", "categoría")
    datos_producto["categoria"] = categoria

    precio = obtener_numero("Precio del producto: ", "precio", float)
    datos_producto["precio"] = precio

    stock = obtener_numero("Stock del producto: ", "stock", int)
    datos_producto["stock"] = stock

    fabricante = obtener_texto("Fabricante del producto: ", "fabricante")
    datos_producto["fabricante"] = fabricante

    return datos_producto

def mostrar_producto(producto):
    """Muestra la información de un producto con formato."""
    print("\n================================")
    print("Información del producto:")
    print(f"ID: {producto.id}")
    print(f"Nombre: {producto.nombre}")
    print(f"Categoría: {producto.categoria}")
    print(f"Precio: {producto.precio}€")
    print(f"Stock: {producto.stock}")
    print(f"Fabricante: {producto.fabricante}")
    print("================================")

def mostrar_menu():
    """Muestra el menú principal con las opciones disponibles."""
    print("\n===== SISTEMA DE GESTIÓN DE INVENTARIO =====")
    print("1. Agregar nuevo producto")
    print("2. Listar todos los productos")
    print("3. Buscar producto")
    print("4. Actualizar producto")
    print("5. Eliminar producto")
    print("0. Salir")
    print("=============================================")

def agregar_producto(gestor_bd):
    """
    Solicita al usuario los datos de un nuevo producto y lo agrega a la BD.
    
    Args:
        gestor_bd (GestorBD): Instancia del gestor de base de datos
    
    Returns:
        bool: True si el producto se agregó correctamente, False en caso contrario.
    """
    print("\n--- Agregar Nuevo Producto ---")
    
    datos_producto = solicitar_datos_producto()

    print("================================")
    print("Estos son los datos del producto:")
    print(f"Nombre: {datos_producto['nombre']}")
    print(f"Categoría: {datos_producto['categoria']}")
    print(f"Precio: {datos_producto['precio']}€")
    print(f"Stock: {datos_producto['stock']}")
    print(f"Fabricante: {datos_producto['fabricante']}")
    print("================================")
    
    confirmacion = input("\n¿Son correctos los datos? (s/n): ").strip().lower()
    if confirmacion != "s":
        print("Operación cancelada. Vuelva a intentarlo.")
        return False

    nuevo_producto = Producto(**datos_producto)
    producto_id = gestor_bd.insertar_producto(nuevo_producto)
    
    if producto_id:
        print(f"\nProducto agregado correctamente con ID: {producto_id}")
        return True
    else:
        print("\nError al agregar el producto. Por favor, inténtelo de nuevo.")
        return False

def listar_productos(gestor_bd):
    """
    Muestra todos los productos del inventario.
    
    Args:
        gestor_bd (GestorBD): Instancia del gestor de base de datos
    """
    print("\n--- Listado de Productos ---")
    
    productos = gestor_bd.obtener_productos()
    
    if not productos:
        print("No hay productos en el inventario.")
        return
    
    print(f"\nTotal de productos: {len(productos)}")
    print("\n" + "-" * 80)
    print(f"{'ID':<5} {'Nombre':<20} {'Categoría':<15} {'Precio':<10} {'Stock':<8} {'Fabricante':<20}")
    print("-" * 80)
    
    for producto in productos:
        print(f"{producto.id:<5} {producto.nombre:<20} {producto.categoria:<15} {producto.precio:<10.2f}€ {producto.stock:<8} {producto.fabricante:<20}")
    
    print("-" * 80)

def buscar_productos(gestor_bd):
    """
    Permite al usuario buscar productos según diferentes criterios.
    
    Args:
        gestor_bd (GestorBD): Instancia del gestor de base de datos
    """
    print("\n--- Buscar Productos ---")
    print("1. Buscar por ID")
    print("2. Buscar por nombre")
    print("3. Buscar por categoría")
    print("4. Buscar por fabricante")
    print("0. Volver al menú principal")
    
    opcion = input("\nSeleccione una opción: ").strip()
    
    if opcion == "0":
        return
    
    if opcion == "1":
        try:
            id_producto = int(input("Introduzca el ID del producto: ").strip())
            producto = gestor_bd.obtener_producto_por_id(id_producto)
            
            if producto:
                mostrar_producto(producto)
            else:
                print(f"No se encontró ningún producto con ID {id_producto}.")
        except ValueError:
            print("Por favor, introduzca un ID válido (número entero).")
    
    elif opcion in ["2", "3", "4"]:
        campos = {
            "2": "nombre",
            "3": "categoria",
            "4": "fabricante"
        }
        
        campo = campos[opcion]
        valor = input(f"Introduzca el {campo} a buscar: ").strip()
        
        if not valor:
            print("Debe introducir un valor para la búsqueda.")
            return
        
        productos = gestor_bd.buscar_productos(campo, valor)
        
        if not productos:
            print(f"No se encontraron productos que coincidan con {campo}: {valor}")
            return
        
        print(f"\nSe encontraron {len(productos)} productos:")
        print("\n" + "-" * 80)
        print(f"{'ID':<5} {'Nombre':<20} {'Categoría':<15} {'Precio':<10} {'Stock':<8} {'Fabricante':<20}")
        print("-" * 80)
        
        for producto in productos:
            print(f"{producto.id:<5} {producto.nombre:<20} {producto.categoria:<15} {producto.precio:<10.2f}€ {producto.stock:<8} {producto.fabricante:<20}")
        
        print("-" * 80)
    
    else:
        print("Opción no válida. Por favor, inténtelo de nuevo.")

def actualizar_producto(gestor_bd):
    """
    Permite al usuario actualizar la información de un producto existente.
    
    Args:
        gestor_bd (GestorBD): Instancia del gestor de base de datos
    
    Returns:
        bool: True si el producto se actualizó correctamente, False en caso contrario.
    """
    print("\n--- Actualizar Producto ---")
    
    try:
        id_producto = int(input("Introduzca el ID del producto a actualizar: ").strip())
        producto = gestor_bd.obtener_producto_por_id(id_producto)
        
        if not producto:
            print(f"No se encontró ningún producto con ID {id_producto}.")
            return False
        
        print("\nProducto encontrado:")
        mostrar_producto(producto)
        
        print("\nIntroduzca los nuevos datos (deje en blanco para mantener el valor actual):")
        
        nombre = input(f"Nombre ({producto.nombre}): ").strip()
        if nombre:
            producto.nombre = nombre
        
        categoria = input(f"Categoría ({producto.categoria}): ").strip()
        if categoria:
            producto.categoria = categoria
        
        precio_str = input(f"Precio ({producto.precio}€): ").strip()
        if precio_str:
            try:
                precio = float(precio_str)
                if precio < 0:
                    print("El precio no puede ser negativo. Se mantiene el valor actual.")
                else:
                    producto.precio = precio
            except ValueError:
                print("Valor de precio no válido. Se mantiene el valor actual.")
        
        stock_str = input(f"Stock ({producto.stock}): ").strip()
        if stock_str:
            try:
                stock = int(stock_str)
                if stock < 0:
                    print("El stock no puede ser negativo. Se mantiene el valor actual.")
                else:
                    producto.stock = stock
            except ValueError:
                print("Valor de stock no válido. Se mantiene el valor actual.")
        
        fabricante = input(f"Fabricante ({producto.fabricante}): ").strip()
        if fabricante:
            producto.fabricante = fabricante
        
        print("\nNuevos datos del producto:")
        mostrar_producto(producto)
        
        confirmacion = input("\n¿Confirma la actualización? (s/n): ").strip().lower()
        if confirmacion != "s":
            print("Operación cancelada.")
            return False
        
        actualizado = gestor_bd.actualizar_producto(producto)
        
        if actualizado:
            print("\nProducto actualizado correctamente.")
            return True
        else:
            print("\nError al actualizar el producto. Por favor, inténtelo de nuevo.")
            return False
    
    except ValueError:
        print("Por favor, introduzca un ID válido (número entero).")
        return False

def eliminar_producto(gestor_bd):
    """
    Permite al usuario eliminar un producto del inventario.
    
    Args:
        gestor_bd (GestorBD): Instancia del gestor de base de datos
    
    Returns:
        bool: True si el producto se eliminó correctamente, False en caso contrario.
    """
    print("\n--- Eliminar Producto ---")
    
    try:
        id_producto = int(input("Introduzca el ID del producto a eliminar: ").strip())
        producto = gestor_bd.obtener_producto_por_id(id_producto)
        
        if not producto:
            print(f"No se encontró ningún producto con ID {id_producto}.")
            return False
        
        print("\nProducto encontrado:")
        mostrar_producto(producto)
        
        confirmacion = input("\n¿Está seguro de que desea eliminar este producto? (s/n): ").strip().lower()
        if confirmacion != "s":
            print("Operación cancelada.")
            return False
        
        eliminado = gestor_bd.eliminar_producto(id_producto)
        
        if eliminado:
            print("\nProducto eliminado correctamente.")
            return True
        else:
            print("\nError al eliminar el producto. Por favor, inténtelo de nuevo.")
            return False
    
    except ValueError:
        print("Por favor, introduzca un ID válido (número entero).")
        return False

def main():
    """Función principal del programa."""
    # Crear el gestor de base de datos
    gestor_bd = GestorBD()

    # Bucle principal del programa
    opcion = None
    while opcion != "0":
        # Mostrar el menú y obtener la opción del usuario
        mostrar_menu()
        opcion = input("Seleccione una opción: ").strip()
        
        if opcion == "1":
            agregar_producto(gestor_bd)
        elif opcion == "2":
            listar_productos(gestor_bd)
        elif opcion == "3":
            buscar_productos(gestor_bd)
        elif opcion == "4":
            actualizar_producto(gestor_bd)
        elif opcion == "5":
            eliminar_producto(gestor_bd)
        elif opcion == "0":
            print("\nSaliendo del programa...")
        else:
            print("\nOpción no válida. Por favor, inténtelo de nuevo.")

    # Cerrar la conexión a la base de datos al salir
    gestor_bd.cerrar_conexion()
    print("\n¡Gracias por usar el Sistema de Gestión de Inventario!")

if __name__ == "__main__":
    main()
