import sqlite3
from producto import Producto


class GestorBD:
    """
    Clase para gestionar la conexión y operaciones con la base de datos SQLite.
    """

    def __init__(self, nombre_bd="inventario.db"):
        """
        Constructor de la clase GestorBD.
        Establece la conexión con la base de datos y crea la tabla si no existe.

        Args:
            nombre_bd (str): Nombre del archivo de la base de datos

        TODO:
        - Establecer la conexión a la base de datos
        - Crear un cursor
        - Crear la tabla productos si no existe
        """
        self.conexion = sqlite3.connect(nombre_bd)
        self.cursor = self.conexion.cursor()
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS productos (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            nombre TEXT NOT NULL,
                            categoria TEXT NOT NULL,
                            precio REAL NOT NULL,
                            stock INTEGER NOT NULL,
                            fabricante TEXT NOT NULL)
        """
        )
        self.conexion.commit()

    def insertar_producto(self, producto):
        """
        Inserta un nuevo producto en la base de datos.

        Args:
            producto (Producto): Objeto Producto a insertar

        Returns:
            int: ID del producto insertado

        TODO:
        - Convertir el producto a valores para SQL
        - Ejecutar la consulta INSERT
        """

        self.cursor.execute(
            """
                INSERT INTO productos (nombre, categoria, precio, stock, fabricante)
                VALUES (?, ?, ?, ?, ?)
                            """,
            (
                producto.nombre,
                producto.categoria,
                producto.precio,
                producto.stock,
                producto.fabricante,
            ),
        )
        self.conexion.commit()
        return self.cursor.lastrowid

    def obtener_productos(self):
        """
        Obtiene todos los productos de la base de datos.

        Returns:
            list: Lista de objetos Producto

        TODO:
        - Ejecutar consulta SELECT para obtener todos los productos
        - Convertir los resultados a objetos Producto
        - Retornar la lista de productos
        """
        self.cursor.execute("SELECT * FROM productos")
        resultados = self.cursor.fetchall()
        productos = []
        for fila in resultados:
            dict_fila = {
                "id": fila[0],
                "nombre": fila[1],
                "categoria": fila[2],
                "precio": fila[3],
                "stock": fila[4],
                "fabricante": fila[5],
            }
            productos.append(Producto.from_dict(dict_fila))
        return productos

    def obtener_producto_por_id(self, id):
        """
        Busca un producto por su ID.

        Args:
            id (int): ID del producto a buscar

        Returns:
            Producto: Objeto Producto encontrado o None si no existe

        TODO:
        - Ejecutar consulta SELECT con WHERE para el ID específico
        - Convertir el resultado a un objeto Producto si existe
        - Retornar el producto o None
        """

        self.cursor.execute("SELECT * FROM productos WHERE id = ?", (id,))
        self.conexion.commit()
        resultado = self.cursor.fetchone()
        if not resultado:
            return None
        producto = {
                "id": resultado[0],
                "nombre": resultado[1],
                "categoria": resultado[2],
                "precio": resultado[3],
                "stock": resultado[4],
                "fabricante": resultado[5],
            }
        return Producto.from_dict(producto)

    def actualizar_producto(self, producto):
        """
        Actualiza los datos de un producto existente.

        Args:
            producto (Producto): Objeto Producto con los nuevos datos

        Returns:
            bool: True si se actualizó correctamente, False en caso contrario

        TODO:
        - Verificar que el producto tiene un ID válido
        - Ejecutar consulta UPDATE con los nuevos valores
        - Retornar True/False según el resultado
        """
        if producto.id is None or producto.id == "N/A":
            return None
        self.cursor.execute(
            """
                            UPDATE productos
                            SET nombre = ?, categoria = ?, precio = ?, stock = ?, fabricante = ? 
                            WHERE id = ?
                            """,
            (
                producto.nombre,
                producto.categoria,
                producto.precio,
                producto.stock,
                producto.fabricante,
                producto.id,
            ),
        )
        self.conexion.commit()
        return self.cursor.rowcount > 0

    def eliminar_producto(self, id):
        """
        Elimina un producto de la base de datos.

        Args:
            id (int): ID del producto a eliminar

        Returns:
            bool: True si se eliminó correctamente, False en caso contrario

        TODO:
        - Ejecutar consulta DELETE para el ID específico
        - Retornar True/False según el resultado
        """
        self.cursor.execute("DELETE FROM productos WHERE id = ?", (id,))
        self.conexion.commit()
        return self.cursor.rowcount > 0

    def buscar_productos(self, criterio, valor):
        """
        Busca productos que coincidan con un criterio y valor.

        Args:
            criterio (str): Campo por el que buscar ('nombre', 'categoria', 'fabricante')
            valor (str): Valor a buscar

        Returns:
            list: Lista de objetos Producto que coinciden con la búsqueda

        TODO:
        - Validar que el criterio sea válido
        - Ejecutar consulta SELECT con WHERE usando LIKE para búsqueda parcial
        - Convertir resultados a objetos Producto
        - Retornar la lista de productos
        """
        productos = []
        permitted_field = ["nombre", "categoria", "fabricante"]
        if criterio not in permitted_field:
            print("No permitido ese criterio")
            return productos
        
        consulta = f"SELECT * FROM productos WHERE {criterio} LIKE ?"
        self.cursor.execute(consulta, (f"%{valor}%",))
        resultados = self.cursor.fetchall()
        
        for fila in resultados:
            dict_fila = {
                "id": fila[0],
                "nombre": fila[1],
                "categoria": fila[2],
                "precio": fila[3],
                "stock": fila[4],
                "fabricante": fila[5],
            }
            productos.append(Producto.from_dict(dict_fila))
        
        return productos

    def cerrar_conexion(self):
        """
        Cierra la conexión con la base de datos.

        TODO:
        - Cerrar la conexión a la base de datos si está abierta
        """
        if self.conexion:
            self.conexion.close()